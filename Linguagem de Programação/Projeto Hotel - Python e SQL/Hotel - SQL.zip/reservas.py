from datetime import datetime
import mysql.connector
import customtkinter
import customtkinter as ctk

# Criando a conexão com banco
conexao = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='',  # Mudar a senha
    database='hotel',
)
cursor = conexao.cursor()

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
  
    #Selecionando a tabela Colaborador
print("")
comando = f'SELECT * FROM colaborador'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
    print(f"CPF: {i[0]}    Nome: {i[1]}    Função: {i[2]}    Carga Horária: {i[3]}    Período: {i[4]}    Salário: {i[5]}")
    print('-' * 92)
    print("")
    
    #Selecionando a tabela Quartos
    
print("")
comando = f'SELECT * FROM quartos'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
        print(f"Número: {i[0]}    Tipo: {i[1]}    Valor: {i[2]}")
        print('-' * 40)
        print("")
    
    #Selecionando a tabela Reservas
print("")
comando = f'SELECT * FROM reserva'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
    print(f"CPF: {i[0]}    Nome: {i[1]}    Data Entrada: {i[2]}    Data Saída: {i[3]}    Quarto: {i[4]}    Valor: {i[5]}")
    print('-' * 112)
    print("")
        