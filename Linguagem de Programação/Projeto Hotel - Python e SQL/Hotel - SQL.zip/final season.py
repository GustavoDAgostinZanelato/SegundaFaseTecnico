from datetime import datetime
import mysql.connector
import customtkinter
import customtkinter as ctk

# Criando a conexão com banco
conexao = mysql.connector.connect(
    host='127.0.0.1',
    user='root',
    password='',  # Mudar a senha
    database='hotel',
)
cursor = conexao.cursor()

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

print("\n Bem-vindo a aba de cadastro de nossos funcionários")
print("-" * 53)

    # Cadastro do CPF
cpf_F_Add = input("Digite o CPF do novo colaborador: ")
num_casas_decimais = len(cpf_F_Add)
if (num_casas_decimais != 3):
    print("Valor Inválido. Tente Novamente")

    # Nome do novo Colaborador
nome_F_Add = input("Insira o nome completo do colaborador: ")

    # Cadastro da área de atuação do funcionário
funcao_Add = input(
        "\n Informe a função do novo colaborador: \n R) Recepcionista \n S) Segurança \n C) Cozinheiro ")
if funcao_Add != "R" and funcao_Add != "S" and funcao_Add != "C":
    print("Informe uma função válido. Tente Novamente")

    # Cadastro da Carga Horária do Colaborador
ch_Add = int(
        input("\nQual o número de horas que o funcionário irá trabalhar? "))
if (ch_Add >= 12):
        print("Informe uma carga horária digna. Tente Novamente")

    # Informando o período do dia que o funcionário irá trabalhar

periodo_Add = input(
    "\nQual o período de trabalho do funcionário: \nM) Matutino \nV) Vespertino \nN) Noturno ")
if periodo_Add != "M" and periodo_Add != "V" and periodo_Add != "N":
    print("Período Inválido. Tente Novamente")

    # Salário dos Funcionarios
if (funcao_Add == "R"):
    salario_Add = 3000.00

elif (funcao_Add == "S"):
    salario_Add = 4000.00

elif (funcao_Add == "C"):
    salario_Add = 6000.00

comando = f'INSERT INTO colaborador (CPF, Nome, Função, Carga  Horária, Período, Salário) VALUES ({cpf_F_Add}, "{nome_F_Add}", "{funcao_Add}", {ch_Add}, "{periodo_Add}", {salario_Add})'
cursor.execute(comando)
conexao.commit()

print("\n Novo colaborador cadastrado com sucesso!")

def reservas():

    print("\n Bem-vindo a aba de cadastro das reservas")

    # Cadastro do CPFwhile True:
    cpf_R_Add = input("Digite o CPF do cliente: ")
    num_casas_decimais = len(cpf_R_Add)
    if (num_casas_decimais != 3):
            print("Valor Inválido. Tente Novamente")

    # Cadastro do Nome do Cliente
    nome_R_Add = input("Informe o nome completo do cliente: ")
    
    #Data de entrada dos reservistas
    de = input("Informe a data de entrada do reservista: ")
    de_obj = datetime.strptime(de, '%d/%m/%Y')

    #Data de saída dos reservistas
    ds = input("Informe a data de saída do reservista: ")
    ds_obj = datetime.strptime(ds, '%d/%m/%Y')

   # Calcula a diferença entre as datas
    diferenca = ds_obj - de_obj

    # Obtém o número de dias como um inteiro
    dias = diferenca.days



    tipo_Add = int(input("Selecione o tipo de quarto desejado: \n1-Solteiro \n2-Casal \n3-Família \n"))
    if(tipo_Add > 3) and (tipo_Add < 1):
        print("Informe uma opção de quarto válida. Tente Novamente")

    #Selecionar o número do quarto disponível

        if(tipo_Add == 1):

            #Verificando quartos ocupados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos = []
            for i in range(len(resultado)):
                    quartos.append(resultado[i][0])
                   

            comando2 = 'SELECT * FROM reserva'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando2)
            resultado2 = cursor.fetchall()  # Lendo o banco de dados
            
            reserva = []
            for i in range(len(resultado2)):
                reserva.append(resultado2[i][4])

            lista3 = list(filter(lambda x: x not in reserva, quartos))


            #Escolha do quarto
            print("")
            valores_novos = [valor for valor in lista3 if valor < 200]
            print("Quartos disponíveis: ", valores_novos)
            numero_Add = int(input("Digite o número do quarto desejado: ")) 

            if numero_Add in lista3:
                print("\n O quarto", numero_Add, "está disponível.")  
            else:
                print("\n O quarto", numero_Add, "á está ocupado. Escolha outro.")
                

        elif(tipo_Add == 2):

             #Verificando quartos ocupados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos = []
            for i in range(len(resultado)):
                    quartos.append(resultado[i][0])
                   

            comando2 = 'SELECT * FROM reserva'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando2)
            resultado2 = cursor.fetchall()  # Lendo o banco de dados
            
            reserva = []
            for i in range(len(resultado2)):
                reserva.append(resultado2[i][4])

            lista3 = list(filter(lambda x: x not in reserva, quartos))


            #Escolha do quarto
            print("")
            valores_novos = [valor for valor in lista3 if 200 <= valor <= 300]
            print("Quartos disponíveis: ", valores_novos)
            numero_Add = int(input("Digite o número do quarto desejado: ")) 

            if numero_Add in lista3:
                print("\n O quarto", numero_Add, "está disponível.") 
            else:
                print("\n O quarto", numero_Add, "á está ocupado. Escolha outro.")
                

        elif(tipo_Add == 3):

                #Verificando quartos ocupados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos = []
            for i in range(len(resultado)):
                    quartos.append(resultado[i][0])
                   

            comando2 = 'SELECT * FROM reserva'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando2)
            resultado2 = cursor.fetchall()  # Lendo o banco de dados
            
            reserva = []
            for i in range(len(resultado2)):
                reserva.append(resultado2[i][4])

            lista3 = list(filter(lambda x: x not in reserva, quartos))


            #Escolha do quarto
            print("")
            valores_novos = [valor for valor in lista3 if 300 <= valor <= 400]
            print("Quartos disponíveis: ", valores_novos)
            numero_Add = int(input("Digite o número do quarto desejado: ")) 

            if numero_Add in lista3:
                print("\n O quarto", numero_Add, "está disponível.") 
            else:
                print("\n O quarto", numero_Add, "á está ocupado. Escolha outro.")
            
    # Determinando o valor do quarto
    if(tipo_Add == 1):
        valor = 400
    elif(tipo_Add == 2):
        valor = 800
    elif(tipo_Add == 3):
        valor = 1200
    
    valor_final = valor * dias

     
    comando = f'INSERT INTO reserva (CPF, Nome, DataEntrada, DataSaída, Quarto, Valor) VALUES ({cpf_R_Add}, "{nome_R_Add}", "{ds_obj}", "{de_obj}", {numero_Add}, {valor_final})' 
    cursor.execute(comando)
    conexao.commit()
    
    print("\n Nova reserva cadastrada com sucesso!")

reservas()

    #Selecionar o tipo do quarto desejado
tipo_Add = int(input("Selecione o tipo de quarto desejado: \n1-Solteiro \n2-Casal \n3-Família \n"))
if(tipo_Add > 3) and (tipo_Add < 1):
            print("Informe uma opção de quarto válida. Tente Novamente")


    #Selecionar o número do quarto disponível

if(tipo_Add == 1):

            #Verificando quartos já cadastrados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos_disponiveis = []
            for i in range(len(resultado)):
                numero_Add_quarto = resultado[i][0]
                if numero_Add_quarto < 200:
                    quartos_disponiveis.append(resultado[i][0])

            #Escolha do quarto
            print("")
            print("Números dos quartos já cadastrados: ", quartos_disponiveis)
            numero_Add = int(input("Digite número do novo quarto: ")) 

           
            if numero_Add in quartos_disponiveis:
                print("\n O quarto", numero_Add, "já está cadastrado. Escolha outro.")
                
            else:
                print("\n O quarto", numero_Add, "está disponível.")
                

elif(tipo_Add == 2):

            #Verificando quartos já cadastrados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos_disponiveis = []
            for i in range(len(resultado)):
                numero_Add_quarto = resultado[i][0]
                if numero_Add_quarto < 300 and numero_Add_quarto > 200:
                    quartos_disponiveis.append(resultado[i][0])

            #Escolha do quarto
            print("")
            print("Números de quartos já cadastrados: ", quartos_disponiveis)
            numero_Add = int(input("Digite número do novo quarto: ")) 

           
            if numero_Add in quartos_disponiveis:
                print("\n O quarto", numero_Add, "já está cadastrado. Escolha outro.")
                
            else:
                print("\n O quarto", numero_Add, "está disponível.")
                
        
elif(tipo_Add == 3):

            #Verificando quartos já cadastrados
            comando = 'SELECT * FROM quartos'  # Selecionando tudo da tabela "quartos"
            cursor.execute(comando)
            resultado = cursor.fetchall()  # Lendo o banco de dados
            
            quartos_disponiveis = []
            for i in range(len(resultado)):
                numero_Add_quarto = resultado[i][0]
                if numero_Add_quarto < 400 and  numero_Add_quarto > 300:
                    quartos_disponiveis.append(resultado[i][0])

            #Escolha do quarto
            print("")
            print("Números de quartos já cadastrados: ", quartos_disponiveis)
            numero_Add = int(input("Digite número do novo quarto: ")) 

           
            if numero_Add in quartos_disponiveis:
                print("\n O quarto", numero_Add, "já está cadastrado. Escolha outro.")
                
            else:
                print("\n O quarto", numero_Add, "está disponível.") 

    # Determinando o valor_Add do quarto
if(tipo_Add == 1):
        valor_Add = 400
elif(tipo_Add == 2):
        valor_Add = 800
elif(tipo_Add == 3):
        valor_Add = 1200


comando = f'INSERT INTO quartos (Número, Tipo, Valor_Add) VALUES ({numero_Add}, {tipo_Add}, {valor_Add})' 
cursor.execute(comando)
conexao.commit()
    
print("\n Novo quarto cadastrado com sucesso!")
print("-" * 37, "\n")

    #Selecionando a tabela Colaborador
print("")
comando = f'SELECT * FROM colaborador'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
    print(f"CPF: {i[0]}    Nome: {i[1]}    Função: {i[2]}    Carga Horária: {i[3]}    Período: {i[4]}    Salário: {i[5]}")
    print('-' * 92)
    print("")
    
    #Selecionando a tabela Quartos
    
print("")
comando = f'SELECT * FROM quartos'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
        print(f"Número: {i[0]}    Tipo: {i[1]}    Valor: {i[2]}")
        print('-' * 40)
        print("")
    
    #Selecionando a tabela Reservas
print("")
comando = f'SELECT * FROM reserva'
cursor.execute(comando)
resultado = cursor.fetchall()
for i in resultado:
    print(f"CPF: {i[0]}    Nome: {i[1]}    Data Entrada: {i[2]}    Data Saída: {i[3]}    Quarto: {i[4]}    Valor: {i[5]}")
    print('-' * 112)
    print("")

#PAREMO NO VISUALIZAR