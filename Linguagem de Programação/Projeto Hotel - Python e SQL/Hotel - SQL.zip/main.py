import customtkinter
import customtkinter as ctk

#aparencia das funcionarios (cor padrão)
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")

#criando janela principal
funcionario = customtkinter.CTk()
#definindo o tamanho da janela principal
funcionario.geometry("900x600")
funcionario.title("Tabela de Funcionarios") #Titulo da janela principal

def AddFuncionario(): #adicionar FUNCIONARIO
    print(cpf_F_Add.get())
    print(nome_F_Add.get())
    print(funcao_Add.get())
    print(ch_Add.get())
    print(periodo_Add.get())
    print(salario_Add.get())

def EdFuncionario(): #editar FUNCIONARIO
    print(cpf_F_Ed.get())
    print(editar_F.get())
    print(novo_F.get())

def ExFuncionario(): #excluir FUNCIONARIO
    print(cpf_F_Ex.get())

#criando janela quartos
quarto = ctk.CTkToplevel(funcionario) #subordinada de "funcionario"
quarto.geometry("900x600") #tamanho padrão
quarto.title("Tabela de Quartos") #titulo da funcionario

def AddQuarto(): #adicionar QUARTO
    print(numero_Add.get())
    print(tipo_Add.get())
    print(valor.get())

def EdQuarto(): #editar QUARTO
    print(numero_Ed.get())
    print(editarQ.get())
    print(novoQ.get())

def ExQuarto(): #excuir QUARTO
    print(numeroEx.get())

#criando janela reservas
reserva = ctk.CTkToplevel(funcionario) #subordinada de "funcionario"
reserva.geometry("900x600") #tamanho padrão
reserva.title("Tabela de Reservas") #titulo da funcionario

def AddReserva(): #adicionar RESERVA
    print(cpf_R_Add.get())
    print(nome_R_Add.get())
    print(de_Add.get())
    print(ds_Add.get())
    print(quarto_Add.get())
    #valor total = valor do quarto * dias

def EdReserva(): #editar RESERVA
    print(cpf_R_Ed.get())
    print(editarR.get())
    print(novoR.get())

def ExReserva(): #excluir RESERVA
    print(cpf_R_Ex.get())

#mensagem introdutoria em FUNCIONÁRIO
texto = customtkinter.CTkLabel(funcionario,
                               text = "Selecione uma das opçoes abaixo para: Funcionário",
                               font=("arial bond", 18))
texto.pack(padx=10, pady=10)
#mensagem introdutoria em QUARTO
texto = customtkinter.CTkLabel(quarto,
                               text = "Selecione uma das opçoes abaixo para: Quarto",
                               font=("arial bond", 18))
texto.pack(padx=10, pady=10)
#mensagem introdutoria em RESERVA
texto = customtkinter.CTkLabel(reserva,
                               text = "Selecione uma das opçoes abaixo para: Reserva",
                               font=("arial bond", 18))
texto.pack(padx=10, pady=10)

#bloco de tabs FUNCIONARIO
tabviewF = ctk.CTkTabview(funcionario, width=400)
tabviewF.pack()#centraliza
#bloco para adicionar os botões
tabviewF.add("Adicionar")
tabviewF.add("Editar")
tabviewF.add("Visualizar")
tabviewF.add("Excluir")
#bloco para posicionar os botões
tabviewF.tab("Adicionar").grid_columnconfigure(0, weight=1)
tabviewF.tab("Editar").grid_columnconfigure(0, weight=1)
tabviewF.tab("Visualizar").grid_columnconfigure(0, weight=1)
tabviewF.tab("Excluir").grid_columnconfigure(0, weight=1)
#fim bloco tabs FUNCIONARIO

#bloco de tabs QUARTO
tabviewQ = ctk.CTkTabview(quarto, width=400)
tabviewQ.pack()#centraliza
#bloco para adicionar os botões
tabviewQ.add("Adicionar")
tabviewQ.add("Editar")
tabviewQ.add("Visualizar")
tabviewQ.add("Excluir")
#bloco para posicionar os botões
tabviewQ.tab("Adicionar").grid_columnconfigure(0, weight=1)
tabviewQ.tab("Editar").grid_columnconfigure(0, weight=1)
tabviewQ.tab("Visualizar").grid_columnconfigure(0, weight=1)
tabviewQ.tab("Excluir").grid_columnconfigure(0, weight=1)
#fim bloco tabs QUARTO

#bloco de tabs RESERVA
tabviewR = ctk.CTkTabview(reserva, width=400)
tabviewR.pack()#centraliza
#bloco para adicionar os botões
tabviewR.add("Adicionar")
tabviewR.add("Editar")
tabviewR.add("Visualizar")
tabviewR.add("Excluir")
#bloco para posicionar os botões
tabviewR.tab("Adicionar").grid_columnconfigure(0, weight=1)
tabviewR.tab("Editar").grid_columnconfigure(0, weight=1)
tabviewR.tab("Visualizar").grid_columnconfigure(0, weight=1)
tabviewR.tab("Excluir").grid_columnconfigure(0, weight=1)
#fim bloco tabs RESERVA

#bloco Adicionar FUNCIONARIO
cpf_F_Add = ctk.CTkEntry(tabviewF.tab("Adicionar"),
                         width=200,
                         placeholder_text="CPF Funcionário")
cpf_F_Add.pack(padx=10, pady=10) #caixa de entrada
nome_F_Add = ctk.CTkEntry(tabviewF.tab("Adicionar"),
                    width=200,
                    placeholder_text="Nome Funcionário")
nome_F_Add.pack(padx=10, pady=10)#caixa de entrada
funcao_Add = ctk.CTkEntry(tabviewF.tab("Adicionar"),
                     width=200,
                     placeholder_text="Função Funcionário")
funcao_Add.pack(padx=10, pady=10) #caixa de entrada
ch_Add = ctk.CTkEntry(tabviewF.tab("Adicionar"),
                     width=200,
                     placeholder_text="Carga horária Funcionário")
ch_Add.pack(padx=10, pady=10) #caixa de entrada
periodo_Add = ctk.CTkOptionMenu(tabviewF.tab("Adicionar"),
                            width=200,
                            values=["Matutino", "Vespertino", "Noturno"])
periodo_Add.pack(padx=10, pady=10)
periodo_Add.set("Periodo")
salario_Add = ctk.CTkEntry(tabviewF.tab("Adicionar"),
                     width=200,
                     placeholder_text="Salario Funcionário")
salario_Add.pack(padx=10, pady=10) #caixa de entrada
#fim bloco Adicionar FUNCIONÁRIO

#bloco para editar FUNCIONÁRIO
cpf_F_Ed = customtkinter.CTkEntry(tabviewF.tab("Editar"),
                                  width=200,
                                  placeholder_text="CPF do funcionário")
cpf_F_Ed.pack(padx=10, pady=10)
editar_F = ctk.CTkOptionMenu(tabviewF.tab("Editar"),
                            width=200,
                            values=["Nome Funcionário", "Função Funcionário", "Carga Horária", "Periodo", "Salário"])
editar_F.pack(padx=10, pady=10)
editar_F.set("modificar campo")
novo_F = customtkinter.CTkEntry(tabviewF.tab("Editar"),
                               width=200,
                               placeholder_text="Digite o novo valor")
novo_F.pack(padx=10, pady=10)
#fim bloco editar FUNCIONÁRIO

"""
nessa parte
vai estar o visualizar
coloque ele dentro
da tabviewF.tab("Visualizar") #tab de VISUALIZAR da janela FUNCIONÁRIO
porque se não
ele vai para a tab errada
ou n aparece
"""


cpf_F_Ex = customtkinter.CTkEntry(tabviewF.tab("Excluir"), #comando excluir FUNCIONÁRIO
                                  width=200,
                                  placeholder_text="Numero do quarto")
cpf_F_Ex.pack(padx=10, pady=10)
#fim bloco FUNCIONÁRIO

#bloco Adicionar QUARTO
numero_Add = ctk.CTkEntry(tabviewQ.tab("Adicionar"),
                         width=200,
                         placeholder_text="Numero do quarto") #caixa de entrada
numero_Add.pack(padx=10, pady=10)
tipo_Add = ctk.CTkEntry(tabviewQ.tab("Adicionar"),
                    width=200,
                    placeholder_text="Tipo do quarto") #caixa de entrada
tipo_Add.pack(padx=10, pady=10)
valor = ctk.CTkEntry(tabviewQ.tab("Adicionar"),
                     width=200,
                     placeholder_text="Valor do quarto") #caixa de entrada
valor.pack(padx=10, pady=10)
#fim bloco Adicionar QUARTO

numero_Ed = customtkinter.CTkEntry(tabviewQ.tab("Editar"),
                                   width=200,
                                   placeholder_text="Numero do quarto")
numero_Ed.pack(padx=10, pady=10)
editarQ = ctk.CTkOptionMenu(tabviewQ.tab("Editar"),
                            width=200,
                            values=["tipo Quarto", "valor Diaria"])
editarQ.pack(padx=10, pady=10)
editarQ.set("modificar campo")
novoQ = customtkinter.CTkEntry(tabviewQ.tab("Editar"),
                               width=200,
                               placeholder_text="Digite o novo valor")
novoQ.pack(padx=10, pady=10)

"""
nessa parte
vai estar o visualizar
coloque ele dentro
da tabviewQ.tab("Visualizar") #tab de VISUALIZAR da janela QUARTO
porque se não
ele vai para a tab errada
ou n aparece
"""

numeroEx = customtkinter.CTkEntry(tabviewQ.tab("Excluir"),
                                  width=200,
                                  placeholder_text="Numero do quarto")
numeroEx.pack(padx=10, pady=10)
#fim bloco QUARTO

#bloco Adicionar RESERVA
cpf_R_Add = ctk.CTkEntry(tabviewR.tab("Adicionar"),
                         width=200,
                         placeholder_text="CPF Reserva")
cpf_R_Add.pack(padx=10, pady=10) #caixa de entrada
nome_R_Add = ctk.CTkEntry(tabviewR.tab("Adicionar"),
                    width=200,
                    placeholder_text="Nome Reserva")
nome_R_Add.pack(padx=10, pady=10)#caixa de entrada
de_Add = ctk.CTkEntry(tabviewR.tab("Adicionar"),
                     width=200,
                     placeholder_text="Data Entrada DD/MM/YYYY")
de_Add.pack(padx=10, pady=10) #caixa de entrada
ds_Add = ctk.CTkEntry(tabviewR.tab("Adicionar"),
                     width=200,
                     placeholder_text="Data Saida DD/MM/YYYY")
ds_Add.pack(padx=10, pady=10) #caixa de entrada
quarto_Add = ctk.CTkEntry(tabviewR.tab("Adicionar"),
                     width=200,
                     placeholder_text="Quarto Reserva")
quarto_Add.pack(padx=10, pady=10) #caixa de entrada
#fim bloco Adicionar RESERVA

cpf_R_Ed = customtkinter.CTkEntry(tabviewR.tab("Editar"),
                                  width=200,
                                  placeholder_text="CPF Reserva")
cpf_R_Ed.pack(padx=10, pady=10)
editarR = ctk.CTkOptionMenu(tabviewR.tab("Editar"),
                            width=200,
                            values=["Nome Reserva", "Data Entrada", "Data Saida", "Quarto Reserva", "Total Reserva"])
editarR.pack(padx=10, pady=10)
editarR.set("modificar campo")
novoR = customtkinter.CTkEntry(tabviewR.tab("Editar"),
                               width=200,
                               placeholder_text="Digite o novo valor")
novoR.pack(padx=10, pady=10)

"""
nessa parte
vai estar o visualizar
coloque ele dentro
da tabviewR.tab("Visualizar") #tab de VISUALIZAR da janela RESERVA
porque se não
ele vai para a tab errada
ou n aparece
"""
#excluir RESERVA
cpf_R_Ex = customtkinter.CTkEntry(tabviewR.tab("Excluir"),
                                  width=200,
                                  placeholder_text="CPF da reserva")
cpf_R_Ex.pack(padx=10, pady=10)
#fim bloco RESERVA

#botoes FUNCIONÁRIO
ctk.CTkButton(tabviewF.tab("Adicionar"),
            width=200,
            text="Enviar", command=AddFuncionario).pack(padx=10,pady=10)
ctk.CTkButton(tabviewF.tab("Editar"), text="Enviar",
            width=200,
            command=EdFuncionario).pack(padx=10,pady=10)
ctk.CTkButton(tabviewF.tab("Excluir"), text="Enviar",
            width=200,
            command=ExFuncionario).pack(padx=10,pady=10)

#botões QUARTO
ctk.CTkButton(tabviewQ.tab("Adicionar"), text="Enviar",
              width=200,
              command=AddQuarto).pack(padx=10,pady=10)
ctk.CTkButton(tabviewQ.tab("Editar"), text="Enviar",
              width=200,
              command=EdQuarto).pack(padx=10,pady=10)
ctk.CTkButton(tabviewQ.tab("Excluir"), text="Enviar",
              width=200,
              command=ExQuarto).pack(padx=10,pady=10)

#botões RESERVA
ctk.CTkButton(tabviewR.tab("Adicionar"),
            width=200,
            text="Enviar", command=AddReserva).pack(padx=10,pady=10)
ctk.CTkButton(tabviewR.tab("Editar"), text="Enviar",
            width=200,
            command=EdReserva).pack(padx=10,pady=10)
ctk.CTkButton(tabviewR.tab("Excluir"), text="Enviar",
            width=200,
            command=ExReserva).pack(padx=10,pady=10)

#loop para executar a funcionario principal
funcionario.mainloop()